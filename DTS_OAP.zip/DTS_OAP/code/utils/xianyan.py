import numpy as np
import matplotlib.pyplot as plt

def display_prior_knowledge_matrices(matrix_pairs):
    num_pairs = len(matrix_pairs)

    fig, axes = plt.subplots(num_pairs, 3, figsize=(18, 4 * num_pairs))

    for i, (original_mask, horizontal_matrix, vertical_matrix) in enumerate(matrix_pairs):
        axes[i, 0].imshow(original_mask.detach().cpu().numpy() , cmap='gray')
        axes[i, 0].set_title('Original Mask')

        axes[i, 1].imshow(horizontal_matrix, cmap='gray')
        axes[i, 1].set_title(f'Horizontal Prior Knowledge - Pair {i + 1}')

        axes[i, 2].imshow(vertical_matrix, cmap='gray')
        axes[i, 2].set_title(f'Vertical Prior Knowledge - Pair {i + 1}')

    plt.tight_layout()
    plt.show()



#横向纵向先验知识矩阵
def generate_shifted_images_batch(image_paths, labeled_bs):
    # Initialize empty lists to store shifted images for each labeled mask
    shifted_images_x_list = []
    shifted_images_y_list = []

    # Loop through each image path in the batch
    for image_path in image_paths[:labeled_bs]:

        image_array = image_path

        # Get the image shape
        shape_length = len(image_array.shape)

        if shape_length == 2:
            # Grayscale image
            height, width = image_array.shape
        elif shape_length == 3:
            # Color image
            _, height, width = image_array.shape
            image_array = image_path[0]
        else:
            raise ValueError(f"Unexpected image shape: {image_array.shape}")

        # Convert the tensor to the CPU and then convert to NumPy
        labeled_mask = (image_array.detach().cpu().numpy() != 0).astype(np.int32)

        horizontal_shift = np.sum(labeled_mask > 0.5, axis=1).astype(np.int32)
        vertical_shift = np.sum(labeled_mask > 0.5, axis=0).astype(np.int32)

        # Initialize shifted images
        shifted_image_horizontal = np.zeros_like(labeled_mask).astype(np.int32)
        shifted_image_vertical = np.zeros_like(labeled_mask).astype(np.int32)

        # Fill shifted_image_horizontal based on horizontal_shift
        for i, n in enumerate(horizontal_shift):
            shifted_image_horizontal[i, :n] = 1


        # Fill shifted_image_vertical based on vertical_shift
        for j, m in enumerate(vertical_shift):
            shifted_image_vertical[:m, j] = 1


        # Append to the lists
        shifted_images_x_list.append(shifted_image_horizontal)
        shifted_images_y_list.append(shifted_image_vertical)

    # Convert lists to NumPy arrays
    shifted_images_x = np.stack(shifted_images_x_list)
    shifted_images_y = np.stack(shifted_images_y_list)

    return shifted_images_x, shifted_images_y




