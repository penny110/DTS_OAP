import numpy as np
import os  # 遍历文件夹
import nibabel as nib
import imageio  # 转换成图像


# 这个是可以成功运行的将.nii文件转换成png格式。
def nii_to_image(filepath, imgfile):
    filenames = os.listdir(filepath)  # 读取nii文件
    imgfile_save = imgfile
    for f in filenames:
        # 开始读取nii文件
        img_path = os.path.join(filepath, f)
        img = nib.load(img_path)  # 读取nii
        img_fdata = img.get_fdata()
        fname = f.replace('.nii.gz', '')  # 去掉nii的后缀名

        # # 开始转换图像
        # (x, y, z) = img.shape
        # for i in range(z):  # 是x的图象序列
        #     slice = img_fdata[:, :, i]  # 选择哪个方向的切片自己决定
        #     imageio.imwrite(os.path.join(imgfile_save, '{}_{}.png'.format(fname, i)), slice)
 # 开始转换图像这个是针对test数据的
        (x, y) = img.shape
        slice = img_fdata[:, :]  # 选择哪个方向的切片自己决定
        imageio.imwrite(os.path.join(imgfile_save, '{}.png'.format(fname)), slice)

if __name__ == '__main__':
    # filepath = r'F:\down_python_project\SSL4MIS-master\SSL4MIS-master\model\tooth\Entropy_Minimization_14_labeled\unet\pre_nii'  # nii文件的路径
    # imgfile = r'F:\down_python_project\SSL4MIS-master\SSL4MIS-master\model\tooth\Entropy_Minimization_14_labeled\unet\predictions'  # 保存png的路径

    filepath = r'F:\new_MC\MC-Net-main\model\gen_mcnet2d_v2_7_labeled\mcnet2d_v2\pre_nii'  # nii文件的路径
    imgfile = r'F:\new_MC\MC-Net-main\model\gen_mcnet2d_v2_7_labeled\mcnet2d_v2\predictions'
    # os.makedirs(imgfile)
    nii_to_image(filepath, imgfile)

