import os

# 数据集文件夹路径
dataset_path = 'D:\\code\\lyk\\BRAIN_TUMOR\\result_of_dataset\\yes'

# 获取数据集文件夹中的所有图像文件
image_files = [f for f in os.listdir(dataset_path) if f.endswith('.jpg') or f.endswith('.png')]

# 重新命名图像文件
for index, old_name in enumerate(image_files):
    file_extension = os.path.splitext(old_name)[1]
    new_name = f'yes{index + 1}{file_extension}'  # 修改成你希望的新命名规则
    old_path = os.path.join(dataset_path, old_name)
    new_path = os.path.join(dataset_path, new_name)
    os.rename(old_path, new_path)