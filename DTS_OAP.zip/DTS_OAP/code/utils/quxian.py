from PIL import Image
import matplotlib.pyplot as plt
import numpy as np

def count_and_save_pixels(image_path):
    # Open the image
    image = Image.open(image_path)

    # Convert to a NumPy array
    image_array = np.array(image)

    # Get the image shape
    shape_length = len(image_array.shape)

    if shape_length == 2:
        # Grayscale image
        height, width = image_array.shape
    elif shape_length == 3:
        # Color image
        height, width, _ = image_array.shape
    else:
        raise ValueError(f"Unexpected image shape: {image_array.shape}")

    # Initialize lists for horizontal and vertical pixel counts
    horizontal_pixel_counts = np.sum(image_array > 0, axis=0)
    vertical_pixel_counts = np.sum(image_array > 0, axis=1)

    # Plot the horizontal pixel counts
    plt.figure(figsize=(width / 100, height / 100), dpi=100)
    plt.plot(horizontal_pixel_counts)
    plt.title('Horizontal Pixel Counts')
    plt.xlabel('Position on X-axis')
    plt.ylabel('Pixel Count')

    # Save the horizontal plot as a file (current location)
    plt.savefig('horizontal_plot.png')

    # Clear the previous plot
    plt.clf()

    # Plot the vertical pixel counts
    plt.figure(figsize=(width / 100, height / 100), dpi=100)
    plt.plot(range(height), vertical_pixel_counts)
    plt.title('Vertical Pixel Counts')
    plt.xlabel('Position on Y-axis')
    plt.ylabel('Pixel Count')

    # Save the vertical plot as a file (current location)
    plt.savefig('vertical_plot.png')

    # Display the plots
    plt.show()

# Replace with the path to your mask-marked image
image_path = 'img.png'

# Call the function to count pixel counts and save plots
count_and_save_pixels(image_path)
