import json
import base64
from PIL import Image
import numpy as np
import os

# 定义图像文件路径
original_image_path = 'F:\MC-Net-main\MC-Net-main\code/utils\data\image\T0.jpg'
mask_image_path = 'F:\MC-Net-main\MC-Net-main\code/utils\data\label\T0.png'
# 获取掩码图像的文件名（不包括扩展名）
original_image_name = os.path.splitext(original_image_path)[0]

# 读取原始图像
original_image = Image.open(original_image_path)
width, height = original_image.size

# 读取标记的掩码图像
mask_image = Image.open(mask_image_path)
mask_array = np.array(mask_image)

# 将原始图像转换为base64编码
with open(original_image_path, 'rb') as image_file:
    image_base64 = base64.b64encode(image_file.read()).decode('utf-8')

# 创建一个列表，用于存储每个标记区域的信息
shapes = []

# 提取标记信息
for label in np.unique(mask_array):
    if label == 0:  # 跳过背景标记
        continue
    region_pixels = np.where(mask_array == label)
    region_info = {
        "label": f"Label{label}",
        "points": np.transpose(region_pixels).tolist(),
        "group_id": None,
        "shape_type": "polygon",
        "flags": {}
    }
    shapes.append(region_info)

# 创建包含图像和标记信息的JSON对象
json_data = {
    "version": "5.0.2",
    "flags": {},
    "shapes": shapes,
    "imagePath": os.path.basename(original_image_path),  # 图像文件名
    "imageData": image_base64,  # 图像的base64编码
    "imageHeight": height,
    "imageWidth": width
}

# 将JSON数据保存到文件（以掩码图像的名称为文件名）
json_filename = original_image_name + '.json'
with open(json_filename, 'w') as json_file:
    json.dump(json_data, json_file, indent=4)