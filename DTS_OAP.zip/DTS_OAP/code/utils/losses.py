import numpy as np
import torch
import torch.nn as nn
from torch.nn import functional as F
from PIL import Image

def Binary_dice_loss(predictive, target, ep=1e-8):
    intersection = 2 * torch.sum(predictive * target) + ep
    union = torch.sum(predictive) + torch.sum(target) + ep
    loss = 1 - intersection / union
    return loss


def kl_loss(inputs, targets, ep=1e-8):
    kl_loss = nn.KLDivLoss(reduction='mean')
    consist_loss = kl_loss(torch.log(inputs + ep), targets)
    return consist_loss


def soft_ce_loss(inputs, target, ep=1e-8):
    logprobs = torch.log(inputs + ep)
    return torch.mean(-(target[:, 0, ...] * logprobs[:, 0, ...] + target[:, 1, ...] * logprobs[:, 1, ...]))


def mse_loss(input1, input2):
    return torch.mean((input1 - input2) ** 2)


def entropy_loss(p, C=2):
    # p N*C*W*H*D
    y1 = -1 * torch.sum(p * torch.log(p + 1e-6), dim=1) / \
         torch.tensor(np.log(C))
    ent = torch.mean(y1)

    return ent


class KDLoss(nn.Module):
    """
    Distilling the Knowledge in a Neural Network
    https://arxiv.org/pdf/1503.02531.pdf
    """

    def __init__(self, T):
        super(KDLoss, self).__init__()
        self.T = T

    def forward(self, out_s, out_t):
        loss = (
            F.kl_div(F.log_softmax(out_s / self.T, dim=1),
                     F.softmax(out_t / self.T, dim=1), reduction="batchmean") # , reduction="batchmean"
            * self.T
            * self.T
        )
        return loss


class DiceLoss(nn.Module):
    def __init__(self, n_classes):
        super(DiceLoss, self).__init__()
        self.n_classes = n_classes

    def _one_hot_encoder(self, input_tensor):
        tensor_list = []
        for i in range(self.n_classes):
            temp_prob = input_tensor == i * torch.ones_like(input_tensor)
            tensor_list.append(temp_prob)
        output_tensor = torch.cat(tensor_list, dim=1)
        return output_tensor.float()

    def _dice_loss(self, score, target):
        target = target.float()
        smooth = 1e-10
        intersection = torch.sum(score * target)
        union = torch.sum(score * score) + torch.sum(target * target) + smooth
        loss = 1 - intersection / union
        return loss

    def forward(self, inputs, target, weight=None, softmax=False):
        if softmax:
            inputs = torch.softmax(inputs, dim=1)
        target = self._one_hot_encoder(target)
        if weight is None:
            weight = [1] * self.n_classes
        assert inputs.size() == target.size(), 'predict & target shape do not match'
        class_wise_dice = []
        loss = 0.0
        for i in range(0, self.n_classes):
            dice = self._dice_loss(inputs[:, i], target[:, i])
            class_wise_dice.append(1.0 - dice.item())
            loss += dice * weight[i]
        return loss / self.n_classes


def generate_shifted_images(image_path):
    # Open the image
    image = Image.open(image_path)

    # Convert to a NumPy array
    image_array = np.array(image)

    # Get the image shape
    shape_length = len(image_array.shape)

    if shape_length == 2:
        # Grayscale image
        height, width = image_array.shape
    elif shape_length == 3:
        # Color image
        height, width, _ = image_array.shape
    else:
        raise ValueError(f"Unexpected image shape: {image_array.shape}")

    # Extract binary mask (assuming white is the region of interest)
    binary_mask = (image_array != 0).astype(np.uint8)

    # Calculate horizontal and vertical shifts
    horizontal_shift = np.argmax(binary_mask, axis=1)
    vertical_shift = np.argmax(binary_mask, axis=0)

    # Generate shifted images
    shifted_image_horizontal = np.zeros_like(binary_mask)
    shifted_image_vertical = np.zeros_like(binary_mask)

    for i in range(height):
        shifted_image_horizontal[i, :width - horizontal_shift[i]] = binary_mask[i, horizontal_shift[i]:]

    for j in range(width):
        shifted_image_vertical[:height - vertical_shift[j], j] = binary_mask[vertical_shift[j]:, j]

    return shifted_image_horizontal, shifted_image_vertical
