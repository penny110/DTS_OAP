from matplotlib import pyplot as plt
from skimage.color.rgb_colors import red, blue, black

# slice, label_png,
def display_images(slice, label_png, p0):
    # Display original image, intermediate result, final result, and prediction side by side

    fig, axes = plt.subplots(1, 3, figsize=(9, 3))
    #
    axes[0].imshow(slice, cmap='gray')
    axes[0].set_title('slice')

    axes[1].imshow(label_png, cmap='gray')
    axes[1].set_title('label')

    # axes[2].imshow(p0[0, 1].cpu().numpy(), cmap='viridis')
    # axes[2].set_title('p0')

    axes[2].imshow(p0, cmap='gray')
    axes[2].set_title('out3')
    plt.show()



def plot_loss(loss_list_1, plot_loss_path):
    plt.figure(figsize=(10, 5))

    freqs = [i for i in range(len(loss_list_1))]

    # 绘制训练损失变化曲线
    plt.plot(freqs, loss_list_1, color=red, label="Train loss")
    # 绘制坐标轴和图例
    plt.ylabel("loss", fontsize='large')
    plt.xlabel("iters", fontsize='large')
    plt.legend(loc='upper right', fontsize='x-large')

    # plt.show()
    plt.savefig(plot_loss_path + "/loss.png")


def plot_loss_cice(loss_list_2, plot_loss_path):
    plt.figure(figsize=(10, 5))

    freqs = [i for i in range(len(loss_list_2))]

    # 绘制训练损失变化曲线
    plt.plot(freqs, loss_list_2, color=blue, label="Train loss_dice")
    # 绘制坐标轴和图例
    plt.ylabel("loss_dice", fontsize='large')
    plt.xlabel("iters", fontsize='large')
    plt.legend(loc='upper right', fontsize='x-large')

    # plt.show()
    plt.savefig(plot_loss_path + "/loss_dice.png")


def plot_loss_consist(loss_list_3, plot_loss_path):
    plt.figure(figsize=(10, 5))

    freqs = [i for i in range(len(loss_list_3))]

    # 绘制训练损失变化曲线
    plt.plot(freqs, loss_list_3, color=black, label="Train loss_consist")
    # 绘制坐标轴和图例
    plt.ylabel("loss", fontsize='large')
    plt.xlabel("iters", fontsize='large')
    plt.legend(loc='upper right', fontsize='x-large')

    # plt.show()
    plt.savefig(plot_loss_path + "/loss_consist.png")
