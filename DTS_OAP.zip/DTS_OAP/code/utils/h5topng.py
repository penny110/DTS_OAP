import os
import h5py
import numpy as np
from PIL import Image
#这个是可以成功运行的将.h5文件转换成png格式。
# 指定.h5文件所在文件夹
h5_folder = 'F:\MC-Net-main\MC-Net-main\data\ACDC\data'  # 替换成您的文件夹路径
# 创建保存图像的子文件夹
image_save_folder = 'F:\MC-Net-main\MC-Net-main\data\ACDC\data\slices_png'

for filename in os.listdir(h5_folder):
    if filename.endswith('.h5'):
        h5_path = os.path.join(h5_folder, filename)

        # 打开.h5文件
        h5_file = h5py.File(h5_path, 'r')

        # 获取图像数据和标签数据
        image_data = h5_file['image'][:]  # 假设图像数据存储在名为'images'的数据集中
        label_data = h5_file['label'][:]  # 假设标签数据存储在名为'labels'的数据集中

        # 关闭.h5文件
        h5_file.close()



        # 遍历图像数据和标签数据，并将它们保存为.png文件
        for i, (img_array, label) in enumerate(zip(image_data, label_data)):
            # 将NumPy数组转换为图像对象
            img_array = (img_array * 255).astype(np.uint8)  # 将浮点数转换为整数
            img = Image.fromarray(img_array)

            # 保存图像为.png格式，可以自定义文件名
            img_path = os.path.join(image_save_folder, filename.split(".")[0]+f'image_{i}.png')
            img.save(img_path)

            # 保存标签信息为文本文件
            label = (label * 255).astype(np.uint8)  # 将浮点数转换为整数
            lab = Image.fromarray(label)
            label_path = os.path.join(image_save_folder, filename.split(".")[0]+f'label_{i}.png')
            lab.save(label_path)
