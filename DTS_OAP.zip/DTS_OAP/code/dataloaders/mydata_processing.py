import glob
import SimpleITK as sitk
import h5py

slice_num = 0
# 将.h5地址串起来
mask_path = sorted(glob.glob("/unlabel/MY/*.png.h5"))
print(mask_path)
for case in mask_path:
    # print(case)
    image = h5py.File(case)['images']  # h5文件路径
    label = h5py.File(case)['masks']
    print(image)
    print(label)
    item = case.split("T")[-1].split(".")[0]
    print(item)
    print(image.shape[0])
    for slice_ind in range(image.shape[0]):
        filename = 'E:/down_python_project/MC-Net-main/MC-Net-main/data_create/destdama/{}_slice_{}.h5'.format(item ,slice_ind+1)
        f = h5py.File(filename, 'w')
        f.create_dataset('images', data=image[slice_ind], compression="gzip")
        f.create_dataset('masks', data=label[slice_ind], compression="gzip")
        f.close()
        slice_num += 1

